This installs the Compal Electronics lpcFilter driver 
used by ECNavigator to control the Acer 5740 fan speed.
If you use Windows 11, try to disable signature check
because the driver is not digitally signed and will
not be installed by this OS. 